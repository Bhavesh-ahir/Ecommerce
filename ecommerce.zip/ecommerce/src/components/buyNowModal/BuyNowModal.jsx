import React, { useState } from 'react';

const BuyNowModal = ({ addressInfo, setAddressInfo, buyNowFunction }) => {
    const [open, setOpen] = useState(false);

    const handleOpen = () => setOpen(!open);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setAddressInfo((prevInfo) => ({
            ...prevInfo,
            [name]: value,
        }));
    };

    return (
        <>
            <button
                type="button"
                onClick={handleOpen}
                className="w-full px-4 py-3 text-center text-gray-100 bg-pink-600 border border-transparent hover:border-pink-500 hover:text-pink-700 hover:bg-pink-100 rounded-xl"
            >
                Buy now
            </button>
            {open && (
                <>
                    <div className="fixed inset-0 flex items-center justify-center z-50">
                        <div className="bg-pink-50 p-5 rounded-lg shadow-lg w-11/12 md:w-1/3">
                            <div className="mb-3">
                                <input
                                    type="text"
                                    name="name"
                                    value={addressInfo.name}
                                    onChange={handleChange}
                                    placeholder="Enter your name"
                                    className="bg-pink-50 border border-pink-200 px-2 py-2 w-full rounded-md outline-none text-pink-600 placeholder-pink-300"
                                />
                            </div>
                            <div className="mb-3">
                                <input
                                    type="text"
                                    name="address"
                                    value={addressInfo.address}
                                    onChange={handleChange}
                                    placeholder="Enter your address"
                                    className="bg-pink-50 border border-pink-200 px-2 py-2 w-full rounded-md outline-none text-pink-600 placeholder-pink-300"
                                />
                            </div>
                            <div className="mb-3">
                                <input
                                    type="number"
                                    name="pincode"
                                    value={addressInfo.pincode}
                                    onChange={handleChange}
                                    placeholder="Enter your pincode"
                                    className="bg-pink-50 border border-pink-200 px-2 py-2 w-full rounded-md outline-none text-pink-600 placeholder-pink-300"
                                />
                            </div>
                            <div className="mb-3">
                                <input
                                    type="text"
                                    name="mobileNumber"
                                    value={addressInfo.mobileNumber}
                                    onChange={handleChange}
                                    placeholder="Enter your mobile number"
                                    className="bg-pink-50 border border-pink-200 px-2 py-2 w-full rounded-md outline-none text-pink-600 placeholder-pink-300"
                                />
                            </div>
                            <div className="flex justify-end">
                                <button
                                    type="button"
                                    onClick={() => {
                                        handleOpen();
                                        buyNowFunction();
                                    }}
                                    className="px-4 py-3 text-center text-gray-100 bg-pink-600 border border-transparent rounded-lg"
                                >
                                    Buy now
                                </button>
                                <button
                                    type="button"
                                    onClick={handleOpen}
                                    className="ml-2 px-4 py-3 text-center text-gray-700 bg-gray-300 border border-transparent rounded-lg"
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                    <div
                        className="fixed inset-0 bg-black opacity-50"
                        onClick={handleOpen}
                    ></div>
                </>
            )}
        </>
    );
};

export default BuyNowModal;
