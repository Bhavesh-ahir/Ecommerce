// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBAD6lJ2RhTdQxL8Q03c9hIHdUg7nAvHeY",
  authDomain: "ecommerce-ec750.firebaseapp.com",
  projectId: "ecommerce-ec750",
  storageBucket: "ecommerce-ec750.appspot.com",
  messagingSenderId: "12400845857",
  appId: "1:12400845857:web:c25333536ea58a3f4fef60",
  measurementId: "G-TG023EJ20F"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const fireDB = getFirestore(app);
const auth = getAuth(app);

const analytics = getAnalytics(app);

export { fireDB, auth }